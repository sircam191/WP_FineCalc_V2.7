-----------------------------------------------------------
WACKPACK Fine and Jail Calculator -V3.0-
-----------------------------------------------------------

INSTALL INSTRUCTIONS:

Make sure the two files* are in the same folder as the FineCalc.exe and run the .exe to open the FineCalc.

*The two files are: ucrtbase.dll, vcruntime140.dll

------------------------------------------------------------------------------------------------------------------------------

-Use option 6 in the main menu to remove a charge or charges you selected.

-If you do not specify a jail it will by default be jail 5 (the prison).

-The calculator currently supports up to 15 charges.

-In the main menu enter 99 for the program information.

-When selecting "Possion Of Dirty Money" it will prompt for the amount of dirty money.

-The max jail time is 30 weeks (min) and the max fine is $50,000.

- Adding more charges after you manually changed the fine or jail time with option 7 
in the main menu will cause the new charges fines and jail times to add to the custom amount you entered.

-If jail time is more than or equal to 10 the jail code will be replaced with the number of community service tasks. (jail time x 3)

------------------------------------------------------------------------------------------------------------------------------

If you are having any issues, find any bugs, or have ideas for improvments feel free to DM me on discord.

-Created by P_O_G#2222



www.thewackpackrp.com

Source Code: https://pastebin.com/QJq7E7vD	[V3.0]